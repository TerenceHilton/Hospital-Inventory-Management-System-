public class InventoryItem {
    private String itemCode;
    private String supplierCode;
    private int quantity;

    public InventoryItem(String itemCode, String supplierCode, int quantity) {
        this.itemCode = itemCode;
        this.supplierCode = supplierCode;
        this.quantity = quantity;
    }

    public String getItemCode() {
        return itemCode;
    }

    public String getSupplierCode() {
        return supplierCode;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return itemCode + "," + supplierCode + "," + quantity;
    }
}
