import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class HospitalsNSuppliersManagement {
    private HospitalManager hospitalManager;
    private SupplierManager supplierManager;
    private JFrame frame;
    private JComboBox<String> hospitalDropdown, supplierDropdown;
    private JTextField hospitalNameField, supplierNameField;
    private JButton updateHospitalBtn, updateSupplierBtn;

    public HospitalsNSuppliersManagement() {
        hospitalManager = new HospitalManager();
        supplierManager = new SupplierManager();
        createUI();
    }

    private void createUI() {
        frame = new JFrame("Hospital & Supplier Management");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        Font labelFont = new Font("Arial", Font.BOLD, 16);
        Font fieldFont = new Font("Arial", Font.PLAIN, 16);
        Font buttonFont = new Font("Arial", Font.BOLD, 18);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(createLabel("Select Hospital:", labelFont), gbc);

        hospitalDropdown = new JComboBox<>(hospitalManager.getHospitals().keySet().toArray(new String[0]));
        hospitalDropdown.setFont(fieldFont);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panel.add(hospitalDropdown, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(createLabel("New Hospital Name:", labelFont), gbc);

        hospitalNameField = createTextField(fieldFont);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panel.add(hospitalNameField, gbc);

        updateHospitalBtn = createStyledButton("Update Hospital", buttonFont);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        panel.add(updateHospitalBtn, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(createLabel("Select Supplier:", labelFont), gbc);

        supplierDropdown = new JComboBox<>(supplierManager.getSuppliers().keySet().toArray(new String[0]));
        supplierDropdown.setFont(fieldFont);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panel.add(supplierDropdown, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        panel.add(createLabel("New Supplier Name:", labelFont), gbc);

        supplierNameField = createTextField(fieldFont);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panel.add(supplierNameField, gbc);

        updateSupplierBtn = createStyledButton("Update Supplier", buttonFont);
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        panel.add(updateSupplierBtn, gbc);

        updateHospitalBtn.addActionListener(this::updateHospital);
        updateSupplierBtn.addActionListener(this::updateSupplier);

        frame.add(panel);
        frame.setVisible(true);
    }

    private JLabel createLabel(String text, Font font) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        return label;
    }

    private JTextField createTextField(Font font) {
        JTextField field = new JTextField(20);
        field.setFont(font);
        return field;
    }

    private JButton createStyledButton(String text, Font font) {
        JButton button = new JButton(text);
        button.setFont(font);
        button.setPreferredSize(new Dimension(200, 40));
        button.setBackground(new Color(211, 211, 211));
        button.setForeground(Color.BLACK);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 1));

        // 鼠标悬停效果
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(176, 176, 176));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(211, 211, 211));
            }
        });

        return button;
    }

    private void updateHospital(ActionEvent e) {
        String selectedCode = (String) hospitalDropdown.getSelectedItem();
        String newName = hospitalNameField.getText().trim();
        if (!newName.isEmpty()) {
            if (hospitalManager.updateHospital(selectedCode, newName)) {
                JOptionPane.showMessageDialog(frame, "Hospital updated!");
            } else {
                JOptionPane.showMessageDialog(frame, "Failed to update hospital.");
            }
        }
    }

    private void updateSupplier(ActionEvent e) {
        String selectedCode = (String) supplierDropdown.getSelectedItem();
        String newName = supplierNameField.getText().trim();
        if (!newName.isEmpty()) {
            if (supplierManager.updateSupplier(selectedCode, newName)) {
                JOptionPane.showMessageDialog(frame, "Supplier updated!");
            } else {
                JOptionPane.showMessageDialog(frame, "Failed to update supplier.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(HospitalsNSuppliersManagement::new);
    }
}
