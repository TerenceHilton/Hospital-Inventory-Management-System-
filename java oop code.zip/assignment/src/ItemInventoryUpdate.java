import java.util.ArrayList;
import java.util.List;

public class ItemInventoryUpdate {
    private List<InventoryItem> inventory = InventoryFile.readInventory();

    public boolean addInventory(String itemCode, int quantity) {
        String supplierCode = InventoryFile.getSupplierByItemCode(itemCode);
        if (supplierCode == null) {
            return false; // If no supplier is found, return false
        }

        InventoryItem item = findItem(itemCode);
        if (item != null) {
            item.setQuantity(item.getQuantity() + quantity);
        } else {
            inventory.add(new InventoryItem(itemCode, supplierCode, quantity));
        }

        InventoryFile.writeInventory(inventory);
        InventoryFile.logTransaction(itemCode, supplierCode, quantity);
        return true;
    }

    public boolean reduceInventory(String itemCode, String hospitalCode, int quantity) {
        InventoryItem item = findItem(itemCode);
        if (item != null && item.getQuantity() >= quantity) {
            item.setQuantity(item.getQuantity() - quantity);
            InventoryFile.writeInventory(inventory);
            InventoryFile.logTransaction(itemCode, hospitalCode, -quantity);
            return true;
        } else {
            return false;
        }
    }

    private InventoryItem findItem(String itemCode) {
        for (InventoryItem item : inventory) {
            if (item.getItemCode().equals(itemCode)) {
                return item;
            }
        }
        return null;
    }

    public List<String[]> getInventoryList() {
        List<String[]> data = new ArrayList<>();
        for (InventoryItem item : inventory) {
            data.add(new String[]{item.getItemCode(), item.getSupplierCode(), String.valueOf(item.getQuantity())});
        }
        return data;
    }
}
