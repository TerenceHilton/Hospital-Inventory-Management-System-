import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class InventoryFile {
    private static final String INVENTORY_FILE = "data/ppe.txt";
    private static final String TRANSACTION_FILE = "data/transactions.txt";
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public static List<InventoryItem> readInventory() {
        List<InventoryItem> inventory = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(INVENTORY_FILE))) {
            br.readLine(); // Skip header line
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    inventory.add(new InventoryItem(parts[0], parts[1], Integer.parseInt(parts[2])));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return inventory;
    }

    public static void writeInventory(List<InventoryItem> inventory) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(INVENTORY_FILE))) {
            bw.write("itemCode,supplierCode,quantityInStock\n");
            for (InventoryItem item : inventory) {
                bw.write(item.toString() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void logTransaction(String itemCode, String supplierOrHospitalCode, int quantity) {
        String dateTime = LocalDateTime.now().format(DATE_FORMATTER);
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(TRANSACTION_FILE, true))) {
            bw.write(itemCode + "," + supplierOrHospitalCode + "," + quantity + "," + dateTime + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getSupplierByItemCode(String itemCode) {
        try (BufferedReader br = new BufferedReader(new FileReader(INVENTORY_FILE))) {
            br.readLine(); // Skip header line
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3 && parts[0].equals(itemCode)) {
                    return parts[1]; // Return the supplier code
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null; // Return null if no supplier found
    }
}
