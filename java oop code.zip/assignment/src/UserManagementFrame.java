import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class UserManagementFrame {
    private JFrame frame = new JFrame("User Management");
    private JList<String> userList;
    private DefaultListModel<String> listModel = new DefaultListModel();
    private JButton addButton;
    private JButton deleteButton;
    private JButton modifyButton;
    private JButton searchButton;
    private JTextField searchField;
    private UserManagement userManagement = new UserManagement();

    public UserManagementFrame() {
        this.frame.setLayout(new BorderLayout());
        this.frame.getContentPane().setBackground(new Color(50, 50, 50));
        this.userList = new JList(this.listModel);
        this.userList.setBackground(new Color(40, 40, 40));
        this.userList.setForeground(Color.WHITE);
        this.userList.setSelectionMode(0);
        JScrollPane scrollPane = new JScrollPane(this.userList);
        this.frame.add(scrollPane, "Center");
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new FlowLayout());
        searchPanel.setBackground(new Color(50, 50, 50));
        JLabel searchLabel = new JLabel("Search User:");
        searchLabel.setForeground(Color.WHITE);
        this.searchField = new JTextField(15);
        this.searchField.setBackground(new Color(30, 30, 30));
        this.searchField.setForeground(Color.WHITE);
        this.searchButton = this.createStyledButton("Search");
        searchPanel.add(searchLabel);
        searchPanel.add(this.searchField);
        searchPanel.add(this.searchButton);
        this.frame.add(searchPanel, "North");
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(1, 3, 10, 10));
        panel.setBackground(new Color(50, 50, 50));
        this.addButton = this.createStyledButton("Add User");
        this.deleteButton = this.createStyledButton("Delete User");
        this.modifyButton = this.createStyledButton("Modify User");
        panel.add(this.addButton);
        panel.add(this.deleteButton);
        panel.add(this.modifyButton);
        this.frame.add(panel, "South");
        this.addButton.addActionListener((e) -> this.addUser());
        this.deleteButton.addActionListener((e) -> this.deleteUser());
        this.modifyButton.addActionListener((e) -> this.modifyUser());
        this.searchButton.addActionListener((e) -> this.searchUser());
        this.updateUserList();
        this.frame.setSize(500, 400);
        this.frame.setDefaultCloseOperation(2);
        this.frame.setLocationRelativeTo((Component)null);
    }

    private JButton createStyledButton(String text) {
        final JButton button = new JButton(text);
        button.setFont(new Font("Arial", 1, 14));
        button.setBackground(new Color(34, 45, 50));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(45, 55, 65));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(new Color(34, 45, 50));
            }
        });
        return button;
    }

    private void updateUserList() {
        this.listModel.clear();

        for(UserFile user : this.userManagement.getUsers()) {
            this.listModel.addElement(user.toString());
        }

    }

    private void addUser() {
        String userId = JOptionPane.showInputDialog(this.frame, "Enter User ID:");
        if (userId != null && !userId.trim().isEmpty()) {
            String name = JOptionPane.showInputDialog(this.frame, "Enter User Name:");
            if (name != null && !name.trim().isEmpty()) {
                String password = JOptionPane.showInputDialog(this.frame, "Enter Password:");
                String userType = JOptionPane.showInputDialog(this.frame, "Enter Role (Admin/Staff):");
                if (password != null && !password.trim().isEmpty() && userType != null && !userType.trim().isEmpty()) {
                    this.userManagement.addUser(userId, name, password, userType);
                    this.updateUserList();
                }
            }
        }

    }

    private void deleteUser() {
        String selectedUser = (String)this.userList.getSelectedValue();
        if (selectedUser != null) {
            String userId = selectedUser.split(",")[0].trim();
            if (this.userManagement.deleteUser(userId)) {
                this.updateUserList();
            }
        } else {
            JOptionPane.showMessageDialog(this.frame, "Please select a user to delete!");
        }

    }

    private void modifyUser() {
        String selectedUser = (String)this.userList.getSelectedValue();
        if (selectedUser != null) {
            String oldUserId = selectedUser.split(",")[0].trim();
            String newUserId = JOptionPane.showInputDialog(this.frame, "Modify User ID:", oldUserId);
            if (newUserId != null && !newUserId.trim().isEmpty()) {
                String newName = JOptionPane.showInputDialog(this.frame, "Modify User Name:", selectedUser.split(",")[1].trim());
                String newPassword = JOptionPane.showInputDialog(this.frame, "Modify Password:", selectedUser.split(",")[2].trim());
                String newUserType = JOptionPane.showInputDialog(this.frame, "Modify Role:", selectedUser.split(",")[3].trim());
                this.userManagement.modifyUser(oldUserId, newUserId, newName, newPassword, newUserType);
                this.updateUserList();
            }
        } else {
            JOptionPane.showMessageDialog(this.frame, "Please select a user to modify!");
        }

    }

    private void searchUser() {
        String searchText = this.searchField.getText().toLowerCase();
        List<UserFile> result = this.userManagement.searchUser(searchText);
        this.listModel.clear();

        for(UserFile user : result) {
            this.listModel.addElement(user.toString());
        }

    }

    public void show() {
        this.frame.setVisible(true);
    }
}
