import java.util.Scanner;

public class Login {
    public Login() {
    }

    public static void main(String[] args) {
        UserManager.loadUsersFromFile("data/users.txt");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter your username:");
        String userID = scanner.nextLine();
        System.out.println("Please enter your password:");
        String password = scanner.nextLine();
        User user = UserManager.login(userID, password);
        if (user != null) {
            System.out.println("Login successful! Welcome, " + user.getName());
            if (user.getUserType().equals("admin")) {
                System.out.println("Administrator interface");
            } else {
                System.out.println("Regular employee interface");
            }
        } else {
            System.out.println("Login failed! Please check your username and password.");
        }

        scanner.close();
    }
}

