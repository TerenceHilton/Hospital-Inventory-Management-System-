import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class InventoryTrackingFrame extends JFrame {
    private InventoryTracker inventoryTracker = new InventoryTracker();

    public InventoryTrackingFrame() {
        this.setTitle("Item Inventory Tracking");
        this.setSize(600, 400);
        this.setDefaultCloseOperation(3);
        this.setLocationRelativeTo((Component)null);
        this.getContentPane().setBackground(new Color(240, 240, 240));
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1, 20, 20));
        panel.setBackground(new Color(240, 240, 240));
        JButton viewAllButton = this.createModernButton("View All Item Inventory");
        viewAllButton.addActionListener((e) -> this.showInventoryTable(this.inventoryTracker.getAllInventory()));
        JButton viewLowStockButton = this.createModernButton("View Items with Less Than 25 Boxes");
        viewLowStockButton.addActionListener((e) -> {
            List<String[]> lowStockItems = this.inventoryTracker.getLowStockItems();
            if (lowStockItems.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All items have more than 25 boxes, inventory is sufficient!");
            } else {
                this.showInventoryTable(lowStockItems);
            }

        });
        JButton viewSpecificItemButton = this.createModernButton("View Specific Item Inventory");
        viewSpecificItemButton.addActionListener((e) -> {
            String itemCode = (String)JOptionPane.showInputDialog(this, "Select Item Code:", "View Inventory", 3, (Icon)null, this.inventoryTracker.getItemCodes(), this.inventoryTracker.getItemCodes()[0]);
            if (itemCode != null) {
                int quantity = this.inventoryTracker.getItemStock(itemCode);
                JOptionPane.showMessageDialog(this, "Item " + itemCode + " stock: " + quantity + " boxes");
            }

        });
        JButton viewTransactionsButton = this.createModernButton("View Inventory Updates within a Time Range");
        viewTransactionsButton.addActionListener((e) -> {
            String startDate = JOptionPane.showInputDialog(this, "Enter Start Date (YYYY-MM-DD):");
            String endDate = JOptionPane.showInputDialog(this, "Enter End Date (YYYY-MM-DD):");
            if (startDate != null && endDate != null) {
                List<String[]> transactions = this.inventoryTracker.getTransactionsInRange(startDate, endDate);
                this.showInventoryTable(transactions);
            }

        });
        panel.add(viewAllButton);
        panel.add(viewLowStockButton);
        panel.add(viewSpecificItemButton);
        panel.add(viewTransactionsButton);
        this.getContentPane().add(panel);
    }

    private void showInventoryTable(List<String[]> data) {
        if (data != null && !data.isEmpty()) {
            String[] columnNames = new String[]{"Item Code", "Supplier/Hospital", "Quantity", "Time"};
            DefaultTableModel model = new DefaultTableModel(columnNames, 0);

            for(String[] row : data) {
                model.addRow(row);
            }

            JTable table = new JTable(model);
            table.setFont(new Font("Segoe UI", 0, 14));
            table.setRowHeight(30);
            table.setFillsViewportHeight(true);
            table.setSelectionBackground(new Color(189, 204, 255));
            JScrollPane scrollPane = new JScrollPane(table);
            JFrame tableFrame = new JFrame("Inventory Data");
            tableFrame.setSize(500, 300);
            tableFrame.setLocationRelativeTo((Component)null);
            tableFrame.add(scrollPane);
            tableFrame.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "No relevant data!");
        }
    }

    private JButton createModernButton(String text) {
        final JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", 0, 16));
        button.setBackground(new Color(228, 224, 225));
        button.setForeground(Color.BLACK);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(new Color(228, 224, 225), 2));
        button.setOpaque(true);
        button.setPreferredSize(new Dimension(250, 50));
        button.setCursor(Cursor.getPredefinedCursor(12));
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(211, 208, 210));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(new Color(228, 224, 225));
            }
        });
        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> (new InventoryTrackingFrame()).setVisible(true));
    }
}