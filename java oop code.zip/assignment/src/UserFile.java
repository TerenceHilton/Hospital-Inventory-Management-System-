import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class UserFile {
    private static final String FILE_PATH = "data/users.txt";
    private static final String DELIMITER = ",";
    private String userId;
    private String name;
    private String password;
    private String userType;

    public static List<UserFile> loadUsersFromFile() {
        List<UserFile> users = new ArrayList();

        String line;
        try (BufferedReader reader = new BufferedReader(new FileReader("data/users.txt"))) {
            while((line = reader.readLine()) != null) {
                String[] userData = line.split(",");
                if (userData.length == 4) {
                    users.add(new UserFile(userData[0], userData[1], userData[2], userData[3]));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return users;
    }

    public static void saveUsersToFile(List<UserFile> users) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("data/users.txt"))) {
            for(UserFile user : users) {
                writer.write(user.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void addUser(UserFile user) {
        List<UserFile> users = loadUsersFromFile();
        users.add(user);
        saveUsersToFile(users);
    }

    public static void deleteUser(String userId) {
        List<UserFile> users = loadUsersFromFile();
        users.removeIf((user) -> user.getUserId().equals(userId));
        saveUsersToFile(users);
    }

    public static void modifyUser(String oldUserId, String newUserId, String newName, String newPassword, String newUserType) {
        List<UserFile> users = loadUsersFromFile();

        for(UserFile user : users) {
            if (user.getUserId().equals(oldUserId)) {
                user.setUserId(newUserId);
                user.setName(newName);
                user.setPassword(newPassword);
                user.setUserType(newUserType);
                break;
            }
        }

        saveUsersToFile(users);
    }

    public static List<UserFile> searchUser(String searchText) {
        List<UserFile> users = loadUsersFromFile();
        List<UserFile> result = new ArrayList();

        for(UserFile user : users) {
            if (user.getName().toLowerCase().contains(searchText.toLowerCase())) {
                result.add(user);
            }
        }

        return result;
    }

    public String toString() {
        return this.userId + "," + this.name + "," + this.password + "," + this.userType;
    }

    public UserFile(String userId, String name, String password, String userType) {
        this.userId = userId;
        this.name = name;
        this.password = password;
        this.userType = userType;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserType() {
        return this.userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }
}
