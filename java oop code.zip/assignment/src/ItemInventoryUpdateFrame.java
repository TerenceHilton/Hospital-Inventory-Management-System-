import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class ItemInventoryUpdateFrame extends JFrame {
    private ItemInventoryUpdate inventoryManagement = new ItemInventoryUpdate();
    private static final String[] ITEM_CODES = {"HC", "FS", "MS", "GL", "GW", "SC"};
    private static final String[] HOSPITAL_CODES = {"H001", "H002", "H003"};

    public ItemInventoryUpdateFrame() {
        setTitle("Item Inventory Management");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        JPanel panel = new JPanel(new GridLayout(3, 1, 20, 20));

        JButton addInventoryButton = createModernButton("Add Inventory", e -> handleAddInventory());
        JButton reduceInventoryButton = createModernButton("Reduce Inventory", e -> handleReduceInventory());
        JButton viewInventoryButton = createModernButton("View Inventory", e -> handleViewInventory());

        panel.add(addInventoryButton);
        panel.add(reduceInventoryButton);
        panel.add(viewInventoryButton);

        getContentPane().add(panel);
    }

    private JButton createModernButton(String text, ActionListener action) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(new Color(70, 130, 180)); // 适度的蓝色
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(180, 50));
        button.addActionListener(action);
        return button;
    }


    private void handleViewInventory() {
        List<String[]> inventoryList = inventoryManagement.getInventoryList();
        if (inventoryList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Inventory is empty.");
            return;
        }

        String[] columnNames = {"Item Code", "Supplier Code", "Quantity"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        for (String[] item : inventoryList) {
            model.addRow(new Object[]{item[0], item[1], item[2]});
        }

        JTable table = new JTable(model);
        table.setRowHeight(25);
        table.setFont(new Font("Arial", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JOptionPane.showMessageDialog(this, scrollPane, "Inventory Details", JOptionPane.INFORMATION_MESSAGE);
    }

    private void handleAddInventory() {
        String itemCode = (String) JOptionPane.showInputDialog(this, "Select Item Code:", "Add Inventory",
                JOptionPane.QUESTION_MESSAGE, null, ITEM_CODES, ITEM_CODES[0]);

        if (itemCode != null) {
            try {
                int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter quantity to add:"));
                boolean result = inventoryManagement.addInventory(itemCode, quantity);
                JOptionPane.showMessageDialog(this, result ? "Inventory added successfully!" : "Failed to add inventory!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid quantity!");
            }
        }
    }

    private void handleReduceInventory() {
        String itemCode = (String) JOptionPane.showInputDialog(this, "Select Item Code:", "Reduce Inventory",
                JOptionPane.QUESTION_MESSAGE, null, ITEM_CODES, ITEM_CODES[0]);

        String hospitalCode = (String) JOptionPane.showInputDialog(this, "Select Hospital Code:", "Reduce Inventory",
                JOptionPane.QUESTION_MESSAGE, null, HOSPITAL_CODES, HOSPITAL_CODES[0]);

        if (itemCode != null && hospitalCode != null) {
            try {
                int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter quantity to reduce:"));
                boolean result = inventoryManagement.reduceInventory(itemCode, hospitalCode, quantity);
                JOptionPane.showMessageDialog(this, result ? "Inventory reduced successfully!" : "Failed to reduce inventory, not enough items!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid quantity!");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ItemInventoryUpdateFrame frame = new ItemInventoryUpdateFrame();
            frame.setVisible(true);
        });
    }
}
