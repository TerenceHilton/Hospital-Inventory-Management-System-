import java.io.*;
import java.util.*;

public class SupplierManager {
    private HashMap<String, String> suppliers = new HashMap<>();
    private final String filePath = "data/suppliers.txt";

    public SupplierManager() {
        loadData();
    }

    // 读取 suppliers.txt 文件数据
    private void loadData() {
        suppliers.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    suppliers.put(parts[0], parts[1]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 获取供应商数据
    public HashMap<String, String> getSuppliers() {
        return suppliers;
    }

    // 更新供应商名称
    public boolean updateSupplier(String code, String newName) {
        if (suppliers.containsKey(code)) {
            suppliers.put(code, newName);
            saveData();
            return true;
        }
        return false;
    }

    // 保存数据到 suppliers.txt
    private void saveData() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (Map.Entry<String, String> entry : suppliers.entrySet()) {
                bw.write(entry.getKey() + "," + entry.getValue());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
