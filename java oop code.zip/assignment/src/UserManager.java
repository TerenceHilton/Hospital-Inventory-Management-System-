import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class UserManager {
    private static List<User> users = new ArrayList();

    public UserManager() {
    }

    public static void loadUsersFromFile(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length < 4) {
                    System.out.println("Invalid user data format: " + line);
                    continue;
                }
                String userID = data[0].trim();
                String name = data[1].trim();
                String password = data[2].trim();
                String userType = data[3].trim();
                users.add(new User(userID, name, password, userType));
            }
        } catch (IOException e) {
            System.out.println("Error loading users from file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static User login(String userID, String password) {
        for(User user : users) {
            if (user.getUserID().equals(userID) && user.getPassword().equals(password)) {
                return user;
            }
        }

        return null;
    }
}
