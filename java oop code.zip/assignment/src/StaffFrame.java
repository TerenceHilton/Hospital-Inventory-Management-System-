import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class StaffFrame extends JFrame {
    private User user;

    public StaffFrame(User user) {
        super("Staff Interface");
        this.user = user;
        this.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = 2;
        gbc.insets = new Insets(10, 10, 10, 10);
        JButton inventoryManagementButton = this.createStyledButton("Inventory Management/Update");
        JButton inventoryTrackingButton = this.createStyledButton("Inventory Tracking");
        JButton searchButton = this.createStyledButton("Search Function");
        JButton logoutButton = this.createStyledButton("Logout");
        gbc.gridx = 0;
        gbc.gridy = 0;
        this.add(inventoryManagementButton, gbc);
        gbc.gridy = 1;
        this.add(inventoryTrackingButton, gbc);
        gbc.gridy = 2;
        this.add(searchButton, gbc);
        gbc.gridy = 3;
        this.add(logoutButton, gbc);
        inventoryManagementButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                StaffFrame.this.openInventoryManagement();
            }
        });
        inventoryTrackingButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                StaffFrame.this.openInventoryTracking();
            }
        });
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                StaffFrame.this.openSearch();
            }
        });
        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        this.setSize(400, 300);
        this.setDefaultCloseOperation(3);
        this.setLocationRelativeTo((Component)null);
    }

    private JButton createStyledButton(String text) {
        final JButton button = new JButton(text);
        button.setFont(new Font("Arial", 1, 14));
        button.setBackground(new Color(34, 45, 50));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(45, 55, 65));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(new Color(34, 45, 50));
            }
        });
        return button;
    }

    private void openInventoryManagement() {
        JOptionPane.showMessageDialog(this, "Open Inventory Management functionality!");
        ItemInventoryUpdateFrame itemInventoryUpdateFrame = new ItemInventoryUpdateFrame();
        itemInventoryUpdateFrame.show();
    }

    private void openInventoryTracking() {
        InventoryTrackingFrame inventoryTrackingFrame = new InventoryTrackingFrame();
        inventoryTrackingFrame.show();
    }

    private void openSearch() {
        SearchFrame searchFrame = new SearchFrame();
        searchFrame.show();
    }
}
