import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class InventoryTracker {
    private static final String INVENTORY_FILE = "data/ppe.txt";
    private static final String TRANSACTIONS_FILE = "data/transactions.txt";

    public InventoryTracker() {
    }

    public List<String[]> getAllInventory() {
        List<String[]> inventoryList = new ArrayList();

        try (BufferedReader br = new BufferedReader(new FileReader("data/ppe.txt"))) {
            br.readLine();

            String line;
            while((line = br.readLine()) != null) {
                String[] data = line.split(",");
                inventoryList.add(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        inventoryList.sort(Comparator.comparing((o) -> o[0]));
        return inventoryList;
    }

    public List<String[]> getLowStockItems() {
        List<String[]> lowStockList = new ArrayList();

        try (BufferedReader br = new BufferedReader(new FileReader("data/ppe.txt"))) {
            br.readLine();

            String line;
            while((line = br.readLine()) != null) {
                String[] data = line.split(",");
                int quantity = Integer.parseInt(data[2]);
                if (quantity < 25) {
                    lowStockList.add(data);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return lowStockList;
    }

    public String[] getItemCodes() {
        List<String> itemCodes = new ArrayList();

        try (BufferedReader br = new BufferedReader(new FileReader("data/ppe.txt"))) {
            br.readLine();

            String line;
            while((line = br.readLine()) != null) {
                String[] data = line.split(",");
                itemCodes.add(data[0]);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return (String[])itemCodes.toArray(new String[0]);
    }

    public int getItemStock(String itemCode) {
        try {
            try (BufferedReader br = new BufferedReader(new FileReader("data/ppe.txt"))) {
                br.readLine();

                String[] data;
                do {
                    String line;
                    if ((line = br.readLine()) == null) {
                        return 0;
                    }

                    data = line.split(",");
                } while(!data[0].equals(itemCode));

                return Integer.parseInt(data[2]);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return 0;
        }
    }

    public List<String[]> getTransactionsInRange(String startDate, String endDate) {
        List<String[]> transactionsList = new ArrayList();

        try (BufferedReader br = new BufferedReader(new FileReader("data/transactions.txt"))) {
            br.readLine();

            String line;
            while((line = br.readLine()) != null) {
                String[] data = line.split(",");
                String date = data[3].split(" ")[0];
                if (date.compareTo(startDate) >= 0 && date.compareTo(endDate) <= 0 && data[1].startsWith("S")) {
                    transactionsList.add(data);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return transactionsList;
    }
}