import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class InventorySearch {
    private static final String TRANSACTIONS_FILE = "data/transactions.txt";
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm");

    public InventorySearch() {
    }

    public static Map<String, Integer> searchItemReceipts(String itemCode, Date startDate, Date endDate) {
        return searchTransactions(itemCode, startDate, endDate, true);
    }

    public static Map<String, Integer> searchItemDistributions(String itemCode, Date startDate, Date endDate) {
        return searchTransactions(itemCode, startDate, endDate, false);
    }

    private static Map<String, Integer> searchTransactions(String itemCode, Date startDate, Date endDate, boolean isReceipt) {
        Map<String, Integer> records = new HashMap();

        try (BufferedReader reader = new BufferedReader(new FileReader("data/transactions.txt"))) {
            String line = reader.readLine();

            while((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    String code = parts[0].trim();
                    String entity = parts[1].trim();
                    int quantity = Integer.parseInt(parts[2].trim());
                    Date date = DATE_FORMAT.parse(parts[3].trim().replace("：", ":"));
                    if (code.equalsIgnoreCase(itemCode) && !date.before(startDate) && !date.after(endDate) && (!isReceipt || quantity >= 0) && (isReceipt || quantity <= 0)) {
                        records.put(entity, (Integer)records.getOrDefault(entity, 0) + Math.abs(quantity));
                    }
                }
            }
        } catch (ParseException | IOException e) {
            ((Exception)e).printStackTrace();
        }

        return records;
    }
}