import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AdminFrame extends JFrame {
    private User user;

    public AdminFrame(User user) {
        super("Admin Interface");
        this.user = user;
        this.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // 创建按钮
        JButton manageUsersButton = createHighlightedButton("Manage Users");
        JButton manageHospitalsSuppliersButton = createHighlightedButton("Manage Hospitals & Suppliers");
        JButton inventoryManagementButton = createStyledButton("Inventory Management/Update");
        JButton inventoryTrackingButton = createStyledButton("Inventory Tracking");
        JButton searchButton = createStyledButton("Search Function");
        JButton logoutButton = createStyledButton("Logout");

        // 添加按钮到界面
        gbc.gridx = 0;
        gbc.gridy = 0;
        this.add(manageUsersButton, gbc);
        gbc.gridy = 1;
        this.add(manageHospitalsSuppliersButton, gbc);
        gbc.gridy = 2;
        this.add(inventoryManagementButton, gbc);
        gbc.gridy = 3;
        this.add(inventoryTrackingButton, gbc);
        gbc.gridy = 4;
        this.add(searchButton, gbc);
        gbc.gridy = 5;
        this.add(logoutButton, gbc);

        // 按钮事件
        manageUsersButton.addActionListener(e -> openUserManagement());
        manageHospitalsSuppliersButton.addActionListener(e -> openHospitalsSuppliersManagement());
        inventoryManagementButton.addActionListener(e -> openInventoryManagement());
        inventoryTrackingButton.addActionListener(e -> openInventoryTracking());
        searchButton.addActionListener(e -> openSearch());
        logoutButton.addActionListener(e -> System.exit(0));

        this.setSize(400, 350);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
    }


    private JButton createStyledButton(String text) {
        final JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(new Color(34, 45, 50));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(45, 55, 65));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(new Color(34, 45, 50));
            }
        });
        return button;
    }


    private JButton createHighlightedButton(String text) {
        final JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(new Color(0, 71, 134));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(12, 25, 12, 25));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(0, 90, 160));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(new Color(0, 71, 134));
            }
        });
        return button;
    }

    private void openUserManagement() {
        new UserManagementFrame().show();
    }

    private void openHospitalsSuppliersManagement() {
        new HospitalsNSuppliersManagement();
    }

    private void openInventoryManagement() {
        new ItemInventoryUpdateFrame().setVisible(true);
    }

    private void openInventoryTracking() {
        new InventoryTrackingFrame().setVisible(true);
    }

    private void openSearch() {
        new SearchFrame().setVisible(true);
    }

    public void showAdminFrame() {
        this.setVisible(true);
    }

}






