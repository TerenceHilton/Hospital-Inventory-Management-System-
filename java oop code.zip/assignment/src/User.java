public class User {
    private String userID;
    private String name;
    private String password;
    private String userType;

    public User(String userID, String name, String password, String userType) {
        this.userID = userID;
        this.name = name;
        this.password = password;
        this.userType = userType;
    }

    public String getUserID() {
        return this.userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserType() {
        return this.userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }
}




