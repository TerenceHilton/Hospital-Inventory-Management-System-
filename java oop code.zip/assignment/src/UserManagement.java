import java.util.List;

public class UserManagement {
    public UserManagement() {
    }

    public List<UserFile> getUsers() {
        return UserFile.loadUsersFromFile();
    }

    public void addUser(String userId, String name, String password, String userType) {
        UserFile newUser = new UserFile(userId, name, password, userType);
        UserFile.addUser(newUser);
    }

    public boolean deleteUser(String userId) {
        List<UserFile> users = UserFile.loadUsersFromFile();
        boolean removed = users.removeIf((user) -> user.getUserId().equals(userId));
        if (removed) {
            UserFile.saveUsersToFile(users);
        }

        return removed;
    }

    public boolean modifyUser(String oldUserId, String newUserId, String newName, String newPassword, String newUserType) {
        UserFile.modifyUser(oldUserId, newUserId, newName, newPassword, newUserType);
        return true;
    }

    public List<UserFile> searchUser(String searchText) {
        return UserFile.searchUser(searchText);
    }
}
