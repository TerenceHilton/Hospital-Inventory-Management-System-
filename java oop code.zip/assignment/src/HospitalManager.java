import java.io.*;
import java.util.*;

public class HospitalManager {
    private HashMap<String, String> hospitals = new HashMap<>();
    private final String filePath = "data/hospitals.txt";

    public HospitalManager() {
        loadData();
    }


    private void loadData() {
        hospitals.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    hospitals.put(parts[0], parts[1]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public HashMap<String, String> getHospitals() {
        return hospitals;
    }


    public boolean updateHospital(String code, String newName) {
        if (hospitals.containsKey(code)) {
            hospitals.put(code, newName);
            saveData();
            return true;
        }
        return false;
    }


    private void saveData() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (Map.Entry<String, String> entry : hospitals.entrySet()) {
                bw.write(entry.getKey() + "," + entry.getValue());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

