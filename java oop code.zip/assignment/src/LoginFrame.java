import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginFrame extends JFrame {
    private JTextField userIDField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public LoginFrame() {
        super("User Login");
        this.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        JLabel userIDLabel = new JLabel("UserID:");
        this.userIDField = new JTextField(20);
        this.userIDField.setFont(new Font("Arial", 0, 14));
        this.userIDField.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        this.userIDField.setPreferredSize(new Dimension(200, 30));
        JLabel passwordLabel = new JLabel("Password:");
        this.passwordField = new JPasswordField(20);
        this.passwordField.setFont(new Font("Arial", 0, 14));
        this.passwordField.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        this.passwordField.setPreferredSize(new Dimension(200, 30));
        this.loginButton = new JButton("Login");
        this.loginButton.setFont(new Font("Arial", 1, 14));
        this.loginButton.setBackground(new Color(60, 120, 255));
        this.loginButton.setForeground(Color.WHITE);
        this.loginButton.setFocusPainted(false);
        this.loginButton.setPreferredSize(new Dimension(100, 35));
        this.loginButton.setCursor(Cursor.getPredefinedCursor(12));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = 17;
        this.add(userIDLabel, gbc);
        gbc.gridx = 1;
        this.add(this.userIDField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        this.add(passwordLabel, gbc);
        gbc.gridx = 1;
        this.add(this.passwordField, gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.anchor = 10;
        this.add(this.loginButton, gbc);
        this.loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                LoginFrame.this.login();
            }
        });
        this.setSize(400, 250);
        this.setDefaultCloseOperation(3);
        this.setLocationRelativeTo((Component)null);
        this.getContentPane().setBackground(new Color(240, 240, 240));
    }

    private void login() {
        String userID = this.userIDField.getText();
        String password = new String(this.passwordField.getPassword());
        User user = UserManager.login(userID, password);
        if (user != null) {
            JOptionPane.showMessageDialog(this, "Login successful! Welcome, " + user.getName(), "Success", 1);
            if (user.getUserType().equals("admin")) {
                (new AdminFrame(user)).setVisible(true);
            } else {
                (new StaffFrame(user)).setVisible(true);
            }

            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Login failed! Please check your UserID and password.", "Failure", 0);
        }

    }

    public static void main(String[] args) {
        UserManager.loadUsersFromFile("data/users.txt");
        (new LoginFrame()).setVisible(true);
    }
}
