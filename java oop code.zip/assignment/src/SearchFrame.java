import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import java.util.Date;
import java.util.Map;

public class SearchFrame extends JFrame {
    private JComboBox<String> itemCodeComboBox;
    private JTextField startDateField;
    private JTextField endDateField;
    private JButton searchReceiveButton;
    private JButton searchDistributionsButton;
    private JTable resultTable;
    private static final String[] ITEM_CODES = new String[]{"HC", "FS", "MS", "GL"};

    public SearchFrame() {
        this.setTitle("Inventory Search");
        this.setSize(600, 450);
        this.setDefaultCloseOperation(3);
        this.setLocationRelativeTo((Component)null);
        this.setLayout(new BorderLayout(20, 20));
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0, 2, 10, 20));
        panel.setBackground(new Color(240, 240, 240));
        JLabel itemCodeLabel = new JLabel("Item Code:");
        itemCodeLabel.setFont(new Font("Segoe UI", 0, 14));
        this.itemCodeComboBox = new JComboBox(ITEM_CODES);
        this.itemCodeComboBox.setFont(new Font("Segoe UI", 0, 14));
        this.itemCodeComboBox.setBackground(Color.WHITE);
        panel.add(itemCodeLabel);
        panel.add(this.itemCodeComboBox);
        JLabel startDateLabel = new JLabel("Start Date (yyyy-MM-dd HH:mm):");
        startDateLabel.setFont(new Font("Segoe UI", 0, 14));
        this.startDateField = new JTextField(16);
        this.startDateField.setFont(new Font("Segoe UI", 0, 14));
        JLabel endDateLabel = new JLabel("End Date (yyyy-MM-dd HH:mm):");
        endDateLabel.setFont(new Font("Segoe UI", 0, 14));
        this.endDateField = new JTextField(16);
        this.endDateField.setFont(new Font("Segoe UI", 0, 14));
        panel.add(startDateLabel);
        panel.add(this.startDateField);
        panel.add(endDateLabel);
        panel.add(this.endDateField);
        this.add(panel, "Center");
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new FlowLayout(1, 20, 20));
        buttonsPanel.setBackground(new Color(240, 240, 240));
        this.searchReceiveButton = this.createModernButton("Search Receive");
        this.searchDistributionsButton = this.createModernButton("Search Distributions");
        buttonsPanel.add(this.searchReceiveButton);
        buttonsPanel.add(this.searchDistributionsButton);
        this.add(buttonsPanel, "South");
        this.resultTable = new JTable();
        this.resultTable.setFont(new Font("Segoe UI", 0, 14));
        this.resultTable.setRowHeight(30);
        this.resultTable.setSelectionBackground(new Color(189, 204, 255));
        this.resultTable.setDefaultEditor(Object.class, (TableCellEditor)null);
        JScrollPane scrollPane = new JScrollPane(this.resultTable);
        this.add(scrollPane, "East");
        this.searchReceiveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SearchFrame.this.searchInventory(true);
            }
        });
        this.searchDistributionsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SearchFrame.this.searchInventory(false);
            }
        });
    }

    private void searchInventory(boolean isReceive) {
        String itemCode = (String)this.itemCodeComboBox.getSelectedItem();

        try {
            Date startDate = InventorySearch.DATE_FORMAT.parse(this.startDateField.getText().trim());
            Date endDate = InventorySearch.DATE_FORMAT.parse(this.endDateField.getText().trim());
            Map<String, Integer> results = isReceive ? InventorySearch.searchItemReceipts(itemCode, startDate, endDate) : InventorySearch.searchItemDistributions(itemCode, startDate, endDate);
            this.displayResults(results);
        } catch (ParseException var6) {
            JOptionPane.showMessageDialog(this, "Invalid date format!", "Error", 0);
        }

    }

    private void displayResults(Map<String, Integer> results) {
        DefaultTableModel model = new DefaultTableModel(new Object[]{"Supplier/Hospital", "Quantity"}, 0);

        for(Map.Entry<String, Integer> entry : results.entrySet()) {
            model.addRow(new Object[]{entry.getKey(), entry.getValue()});
        }

        this.resultTable.setModel(model);
    }

    private JButton createModernButton(String text) {
        final JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", 0, 16));
        button.setBackground(new Color(85, 154, 255));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(new Color(85, 154, 255), 2));
        button.setOpaque(true);
        button.setPreferredSize(new Dimension(150, 40));
        button.setCursor(Cursor.getPredefinedCursor(12));
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(64, 121, 203));
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(new Color(85, 154, 255));
            }
        });
        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> (new SearchFrame()).setVisible(true));
    }
}